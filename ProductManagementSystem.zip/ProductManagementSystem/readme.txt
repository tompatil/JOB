About the project:

I haven’t worked with Angular before, so I implemented the project using HTML instead. (I’m confident I can learn Angular within two weeks with practice.)

I used an array instead of Database because MySQL Workbench was automatically crashing during setup.

To avoid timeout (404) errors while uploading Excel files, I first retrieve the total number of rows and then insert the data in batches, one after another.