
let page = 1, limit = 5, totalPages = 1, sort = '', search = '', editId = null;

async function fetchProducts() {
  const res = await fetch(`/api/products?page=${page}&limit=${limit}&sort=${sort}&search=${search}`);
  const data = await res.json();
  totalPages = data.totalPages;
  displayProducts(data.data);
  document.getElementById('pageInfo').innerText = `Page ${page} of ${totalPages}`;
}

function displayProducts(products) {
  const tbody = document.querySelector('#productTable tbody');
  tbody.innerHTML = '';
  products.forEach(p => {
    const row = `<tr>
      <td>${p.id}</td>
      <td>${p.name}</td>
      <td>${p.price}</td>
      <td>
        <button onclick="editProduct(${p.id}, '${p.name}', ${p.price})">Edit</button>
        <button onclick="deleteProduct(${p.id})">Delete</button>
      </td>
    </tr>`;
    tbody.innerHTML += row;
  });
}

//  Add Product
async function addProduct() {
  const name = document.getElementById('name').value;
  const price = document.getElementById('price').value;
  if (!name || !price) return alert('Enter both name and price');
  await fetch('/api/products', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, price })
  });
  fetchProducts();
}

//  Edit Product
function editProduct(id, name, price) {
  editId = id;
  document.getElementById('name').value = name;
  document.getElementById('price').value = price;
}

//  Update Product
async function updateProduct() {
  if (!editId) return alert('Select a product to update');
  const name = document.getElementById('name').value;
  const price = document.getElementById('price').value;
  await fetch(`/api/products/${editId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, price })
  });
  editId = null;
  fetchProducts();
}

//  Delete Product
async function deleteProduct(id) {
  await fetch(`/api/products/${id}`, { method: 'DELETE' });
  fetchProducts();
}

//  Pagination and Sorting
function nextPage() { if (page < totalPages) { page++; fetchProducts(); } }
function prevPage() { if (page > 1) { page--; fetchProducts(); } }
function sortAsc() { sort = 'asc'; fetchProducts(); }
function sortDesc() { sort = 'desc'; fetchProducts(); }
function searchProducts() { search = document.getElementById('search').value; page = 1; fetchProducts(); }

//  Export Excel
function exportExcel() {
  fetch(`/api/products?page=1&limit=1000`)
    .then(res => res.json())
    .then(data => {
      const ws = XLSX.utils.json_to_sheet(data.data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Products");
      XLSX.writeFile(wb, "Products.xlsx");
    });
}

// Import Excel
async function importExcel() {
  const fileInput = document.getElementById('excelFile');
  const file = fileInput.files[0];
  if (!file) return alert('Please select an Excel file.');

  const reader = new FileReader();
  reader.onload = async (e) => {
    const data = new Uint8Array(e.target.result);
    const workbook = XLSX.read(data, { type: 'array' });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(sheet);

    if (rows.length === 0) return alert('No data found.');

    const batchSize = Math.ceil(rows.length / 4);
    const totalBatches = Math.ceil(rows.length / batchSize);

    for (let i = 0; i < rows.length; i += batchSize) {
      const batch = rows.slice(i, i + batchSize);
      console.log(`Uploading batch ${Math.floor(i / batchSize) + 1} of ${totalBatches}`);

      await fetch('/api/products/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ batch })
      });
    }

    alert('All batches uploaded successfully!');
    await fetchProducts(); // Refresh table
  };

  reader.readAsArrayBuffer(file);
}

//  Allow only numeric input in price
function isNumberKey(evt) {
  const charCode = evt.which ? evt.which : evt.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) return false;
  return true;
}

window.onload = fetchProducts;
